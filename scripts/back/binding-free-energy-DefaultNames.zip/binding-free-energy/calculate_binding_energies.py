#!/usr/bin/python3
USAGE="\
Calculates protein-ligand binding energy from a set of allLigands. \n\
USAGE: calculate_binding_energies.py <Protein pdbqt file> <Ligands dir>"

import os, sys
#-----------
# Main
#-----------
args = sys.argv
if (len (args) < 2):
	print (USAGE)
	sys.exit (0)
#----------------------------------------------------------------------
# Main
#----------------------------------------------------------------------
def main ():
	protein	      = args [1]
	allLigandsDir = args [2]

	allLigands = os.listdir (allLigandsDir)
	for ligand in allLigands:
		calculateBindingEnergy (protein, ligand, allLigandsDir)

print (os.getcwd())

#----------------------------------------------------------------------
# Calculate Free Binding Energy for a ligand creating its own dir
#----------------------------------------------------------------------
def calculateBindingEnergy (protein, ligand, allLigandsDir):
	dirLigand = ligand.split ("_")[0].replace ("conf", "conformation")
	print (">>>", dirLigand)
	os.system ("mkdir %s" % dirLigand)
	os.chdir (dirLigand)
	os.system ("ln -s ../protein.pdbqt")
	os.system ("ln -s ../%s/%s %s" % (allLigandsDir, ligand, "ligand.pdb"))

	#1) Preparing a protein
	#prepare_receptor4.py -r protein.pdb 

	#2) Preparing a ligand
	os.system ("prepare_ligand4.py -l ligand.pdb")
	#3) Generating a grid parameter file
	os.system ("prepare_gpf4.py -l ligand.pdbqt -r protein.pdbqt -y")
	#4) Generating maps and grid data files
	os.system ("autogrid4 -p protein.gpf")
	#5) Generating a docking parameter file
	os.system ("prepare_dpf4.py -l ligand.pdbqt -r protein.pdbqt")

	#6) Modifying docking parameters file
	parLines = []
	with open ("ligand_protein.dpf") as parFile:
		parLines = parFile.readlines()[0:13]
	parLines.append ("epdb                            # **add** this to evaluate the small molecule")
	with open ("ligand_protein.dpf", "w") as parFile:
		parFile.writelines(parLines)

	#7) Running AutoDock
	os.system ("autodock4 -p ligand_protein.dpf -l scoring_result.log")

	os.chdir ("..")


#------------ main -------------
main ()
