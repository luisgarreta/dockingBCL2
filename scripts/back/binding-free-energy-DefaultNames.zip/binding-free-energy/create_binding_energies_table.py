#!/usr/bin/python3
USAGE="\
Create free binding energies table from log file in each ligand results dir.\n\
USAGE: create_binding_energies_table.py"

import os

#--------------------------------------------------------------------
#--------------------------------------------------------------------
def main ():
    ligandsDirs = [x for x in os.listdir (".") if "conformation" in x]

    energiesList = ["Conformation,BindingEnergy"]
    for dir in ligandsDirs:
        energy = getBindingEnergy (dir)
        energiesList.append ("%s,%s" % (dir, energy))

    energiesLines = "\n".join (energiesList)
    open ("Binding_Energies_Table.csv", "w").writelines (energiesLines)

#--------------------------------------------------------------------
#--------------------------------------------------------------------
def getBindingEnergy (dir):
    logLines = open ("%s/%s" % (dir, "scoring_result.log")).readlines ()
    for line in logLines:
        if ("Estimated Free Energy" in line):
            energy = line.split ()[8]
            return (energy)
#--------------------------------------------------------------------
#--------------------------------------------------------------------
main()
