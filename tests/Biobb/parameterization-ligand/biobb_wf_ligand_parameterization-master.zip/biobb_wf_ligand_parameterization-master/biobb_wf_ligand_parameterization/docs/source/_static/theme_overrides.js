$(document).ready(function(){
	$('.icon.icon-home').html('<img src="_static/logo.png" class="logo" alt="Logo">');
});